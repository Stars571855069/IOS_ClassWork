var mysql = require('mysql');
var express = require('express');
var router = express.Router();

/* GET home page. */


var dbConnection = mysql.createConnection({
    host: '127.0.0.1',
    user: 'root',
    password: '86456343',
    database: 'AimaijiIOSDataBase'
});

/* GET home page. */
router.use('/', function(req, res, next)
{
    var obj={"data":{}};
    dbConnection.query('SELECT * FROM typeinfo',function (err, result) {
        if (err) {
            //"retCode":1,
            obj.data.code=1;

            dbConnection.end();
        }
        else{
            obj.data.code=0;
            obj.data.typelist=result;
            console.log(result);
            }
        res.send(obj);
    });

    // dbConnection.end(function () {
    //      console.log("end connect");
    //  });
});


// router.post('/', function(req, res, next)
// {
//
//     var infogoto=req.body.brandname;
//
//     var dbConnection = mysql.createConnection({
//         host: 'localhost',
//         user: 'root',
//         password: '86456343',
//         database: 'AimaijiIOSDataBase'
//     });
//     console.log(infogoto);
//     var sql = ("select * from iteminfo where itembrand = '"+infogoto+"' ");
//     dbConnection.query(sql,function (err,results) {
//         if(err)
//         {
//             throw err;
//
//         }
//         else {
//             console.log(results);
//             if (results[0]) {
//
//                 res.render('ItemBought',{title:"品牌商品",goods:results});
//                 //     res.redirect('/SearchResults');
//
//             }
//             else res.send( '<script>alert("未找到该品牌的手机");window.location.href="/ShopItemType"</script>');
//         }
//     });
//     dbConnection.end(function () {
//         console.log("end connect");
//     });
// });


module.exports = router;