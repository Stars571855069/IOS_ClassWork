//
//  MyCollectionTableViewCell.h
//  AimaiJiApplication
//
//  Created by DMT on 2018/12/27.
//  Copyright © 2018年 Stars. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyCollectionTableViewCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UIView *cocellview;

@property (weak, nonatomic) IBOutlet UIImageView *cophoto;
@property (weak, nonatomic) IBOutlet UILabel *coname;
@property (weak, nonatomic) IBOutlet UIButton *cobutton;
@property (weak, nonatomic) IBOutlet UILabel *coprice;

+(instancetype)MyCollectionTableViewCell;

@end
