//
//  SearchResultViewController.m
//  AimaiJiApplication
//
//  Created by DMT on 2018/12/27.
//  Copyright © 2018年 Stars. All rights reserved.
//

#import "SearchResultViewController.h"
#import "SearchResultTableViewCell.h"
#import "AFNetworking.h"


@interface SearchResultViewController ()

{
    NSArray * resultarray;
}

@property (weak, nonatomic) IBOutlet UIView *searchresultcontainer;
@property (strong, nonatomic) IBOutlet UITableView *tableView;
@property (weak, nonatomic) IBOutlet UILabel *resultinfo;



@end

@implementation SearchResultViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self settable];
    //1.创建会话管理者
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    
    //设置请求数据格式自动转换为JSON
    manager.requestSerializer = [AFJSONRequestSerializer serializer];
    
    // manager.responseSerializer.acceptableContentTypes = [NSSet setWithObjects:@"application/json", @"text/plain",@"text/html", nil];
    
    NSUserDefaults *userinfo = [NSUserDefaults standardUserDefaults];
    NSString *content = [userinfo objectForKey:@"savedsearchcontent"];


    NSDictionary *paramDict = @{
                                @"apicode":@"search",
                                @"args":@{
                                        @"content":content
                                        }
                                
                                };
    
    [manager POST:@"http://localhost:3000/Search" parameters:paramDict progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        
        NSLog(@"%@---%@",[responseObject class],responseObject);
        NSString *code=responseObject[@"data"][@"code"];
        int returncode = [code intValue];
        NSLog(@"%d",returncode);
        
        if (returncode!=0){
            if(returncode!=2){
                self.resultinfo.hidden=false;
                self.searchresultcontainer.hidden=true;
            }
            else if(returncode==2){
                NSLog(@"找到了符合搜索条件的物品");
                
                self.resultinfo.hidden=true;
                self.searchresultcontainer.hidden=false;
                self->resultarray=responseObject[@"data"][@"resultlist"];}
                [self.tableView reloadData];
            }
            else{
                NSLog(@"搜索失败");
            };
       
        
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        NSLog(@"请求失败--%@",error);
    }];
};



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(instancetype)init
{
    
    UINavigationItem *navitem=self.navigationItem;
    navitem.title=@"搜索结果";
    
    return self;
    
    
}


//-----------------------------------------------------------------------------
-(void)settable{
    //初始化tableView,并给tableView设置frame以及样式
    //float tarbarheight=[[UIApplication sharedApplication] statusBarFrame].size.height;
    //self.tablecontainer=[[UIView alloc]initWithFrame:CGRectMake(0, 0, 375, kScreenHeight-tarbarheight*2)];
    self.tableView = [[UITableView alloc] initWithFrame:[UIScreen mainScreen].bounds style:UITableViewStylePlain];
    //遵守代理和数据源(因为要用到代理和数据源方法)
    self.tableView.delegate = (id)self;
    self.tableView.dataSource = (id)self;
    //添加到ViewController的视图中
    [self.searchresultcontainer addSubview:self.tableView];
    
    
    //self.tableView.frame=[CGRectMake(0, 30, 375, kScreenHeight-tarbarheight-30-10)];
    self.searchresultcontainer.backgroundColor=[UIColor colorWithRed:250.0/255.0 green:251.0/255.0 blue:255.0/255.0 alpha:1];
    self.tableView.backgroundColor=[UIColor colorWithRed:250.0/255.0 green:251.0/255.0 blue:255.0/255.0 alpha:1];
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self->resultarray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    //指定cell的重用标识符
    static NSString *reuseIdentifier = @"SearchResultTableViewCell";
    //去缓存池找名叫reuseIdentifier的cell
    SearchResultTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:reuseIdentifier];
    //如果缓存池中没有,那么创建一个新的cell
    if (!cell) {
        cell = [SearchResultTableViewCell SearchResultTableViewCell];
    }
    //        if(!self->resultarray[indexPath.row][@"typeinst"])
    //        {
    //            NSString *typeinst=@"该品牌暂无介绍！";
    //            cell.Typecellinst.text = typeinst;
    //        }
    //    else{
    //        cell.Typecellinst.text = self->resultarray[indexPath.row][@"typeinst"];
    //    }
    cell.searchresultname.text = self->resultarray[indexPath.row][@"itemname"];
    cell.searchresultphoto.image = [UIImage imageNamed:@"appleicon.png"];
    
    
    //返回当前cell
    return cell;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 125;
}


@end


    

    

