//
//  MyProfileViewController.m
//  AimaiJiApplication
//
//  Created by DMT on 2018/11/29.
//  Copyright © 2018年 Stars. All rights reserved.
//

#import "MyProfileViewController.h"
#import "UserProfilePageViewController.h"
#import "SystemSettingPageViewController.h"
#import "RegisterPageViewController.h"
#import "LoginPageViewController.h"

@interface MyProfileViewController ()
@property (weak, nonatomic) IBOutlet UIButton *viewprofilebutton;
@property (weak, nonatomic) IBOutlet UIButton *changepicture;
@property (weak, nonatomic) IBOutlet UIButton *settingbutton;
@property (weak, nonatomic) IBOutlet UIButton *aboutbutton;
@property (weak, nonatomic) IBOutlet UIButton *collectionpagebutton;

@end

@implementation MyProfileViewController
- (IBAction)buttonClick {
    
    UserProfilePageViewController *profileview=[[UserProfilePageViewController alloc]init];
    [self.navigationController pushViewController:profileview animated:YES];
}
- (IBAction)viewsettingPage {
    SystemSettingPageViewController *viewsetting=[[SystemSettingPageViewController alloc]init];
    [self.navigationController pushViewController:viewsetting animated:YES];
}


-(instancetype)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrnil
{
    self =[super initWithNibName:nibNameOrNil bundle:nibBundleOrnil];
    if(self){
        //获取tabBarItem属性所指向的UITabBarItem对象
        UITabBarItem *tbi=self.tabBarItem;
        //设置UITabBarItem对象的标题
        tbi.title=@"我的";
        //设置UITabBarItem对象的图像
        UIImage *i =[UIImage imageNamed:@"Time.png"];
        //将UIImage对象赋给标签的image属性
        tbi.image=i;
    }
    UINavigationItem *navitem=self.navigationItem;
    navitem.title=@"我的";
    return self;
}

@end
