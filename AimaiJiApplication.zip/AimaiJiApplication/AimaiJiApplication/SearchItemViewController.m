//
//  SearchItemViewControler.m
//  AimaiJiApplication
//
//  Created by DMT on 2018/11/29.
//  Copyright © 2018年 Stars. All rights reserved.
//
#define kScreenWidth [UIScreen mainScreen].bounds.size.width
#define kScreenHeight [UIScreen mainScreen].bounds.size.height

#import "SearchItemViewController.h"
#import "SearchResultViewController.h"
#import "TypeDetailViewController.h"
#import "ItemTypeTableViewCell.h"
#import "ItemTypeContainViewController.h"
#import "AFNetworking.h"

@interface SearchItemViewController()
{
    NSArray * resultarray;
}
@property(nonatomic,weak) IBOutlet UITextField *searchText;
//@property(nonatomic,weak) IBOutlet UIButton *typeicon1;
//@property(nonatomic,weak) IBOutlet UIButton *typeicon2;
@property (weak, nonatomic) IBOutlet UIScrollView *tablecontainer;

@property (strong, nonatomic) IBOutlet UITableView *tableView;
//@property(nonatomic,weak) IBOutlet UIButton *typeicon3;
@end

@implementation SearchItemViewController

-(void)viewWillAppear:(BOOL)animated{
    
//    CGRect scrollsize=CGRectMake(0,0, 375, 1350);
//    CGRect mainSize=scrollsize;
//    mainSize.size.height*=1;
//    self.tablecontainer.frame=scrollsize;
//
//    self.tablecontainer.contentSize = mainSize.size;
//    [self.tablecontainer addSubview:self.tableView];
    //[self.view addSubview:self.tablecontainer];
    
    
    
    //1.创建会话管理者
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    
    //设置请求数据格式自动转换为JSON
    manager.requestSerializer = [AFJSONRequestSerializer serializer];
    
    // manager.responseSerializer.acceptableContentTypes = [NSSet setWithObjects:@"application/json", @"text/plain",@"text/html", nil];
    //
    NSDictionary *paramDict = @{
                                @"apicode":@"typedisplay",
                                };
    //2.发送POST请求
    /*
     第一个参数:请求路径(不包含参数).NSString
     第二个参数:字典(发送给服务器的数据~参数)
     第三个参数:progress 进度回调
     第四个参数:success 成功回调
     task:请求任务
     responseObject:响应体信息(JSON--->OC对象)
     第五个参数:failure 失败回调
     error:错误信息
     响应头:task.response
     */
    [manager POST:@"http://localhost:3000/ShopItemType" parameters:paramDict progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        
        NSLog(@"%@---%@",[responseObject class],responseObject);
        if ((int) responseObject[@"data"][@"code"]!=0){
            NSLog(@"读取成功");
            self->resultarray=responseObject[@"data"][@"typelist"];
            [self.tableView reloadData];

            
        }else{
            NSLog(@"未找到数据");
            
        }
        
        
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        NSLog(@"请求失败--%@",error);
    }];
}

//-----------------------------------------------------------------------------
-(void)settable{
    //初始化tableView,并给tableView设置frame以及样式
    float tarbarheight=[[UIApplication sharedApplication] statusBarFrame].size.height;
    //self.tablecontainer=[[UIView alloc]initWithFrame:CGRectMake(0, 0, 375, kScreenHeight-tarbarheight*2)];
    //self.tableView = [[UITableView alloc] initWithFrame:[UIScreen mainScreen].bounds style:UITableViewStylePlain];
    //遵守代理和数据源(因为要用到代理和数据源方法)
     self.tableView.delegate = (id)self;
     self.tableView.dataSource = (id)self;
     //添加到ViewController的视图中
     [self.tablecontainer addSubview:self.tableView];
    [self.view addSubview:_tablecontainer];
    
    
    //self.tableView.frame=[CGRectMake(0, 30, 375, kScreenHeight-tarbarheight-30-10)];
    self.tablecontainer.backgroundColor=[UIColor colorWithRed:250.0/255.0 green:251.0/255.0 blue:255.0/255.0 alpha:1];
    self.tableView.backgroundColor=[UIColor colorWithRed:250.0/255.0 green:251.0/255.0 blue:255.0/255.0 alpha:1];
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

 -(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
     return self->resultarray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    //指定cell的重用标识符
         static NSString *reuseIdentifier = @"ItemTypeTableViewCell";
         //去缓存池找名叫reuseIdentifier的cell
         ItemTypeTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:reuseIdentifier];
         //如果缓存池中没有,那么创建一个新的cell
         if (!cell) {
                 cell = [ItemTypeTableViewCell ItemTypeTableViewCell];
             }
//
        cell.Typecellname.text = self->resultarray[indexPath.row][@"typename"];

        [cell.Typecellphoto setImage:[UIImage imageNamed:self->resultarray[indexPath.row][@"typeimage"]]];
    
        //cell.hiddenimageurl.text=self->resultarray[indexPath.row][@"typeimage"];
        //cell.hiddenimageurl.hidden=true;

         return cell;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
   return 112;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    NSLog(@"选中了第%li个cell", (long)indexPath.row);
    //将cell传递的数据保存在userdefault中，在对应页面加载时调取这些数据
    NSUserDefaults *userinfo = [NSUserDefaults standardUserDefaults];
    NSString *savebrand = self->resultarray[indexPath.row][@"typename"];
    NSString *saveimg = self->resultarray[indexPath.row][@"typeimage"];
    [userinfo setObject:savebrand forKey:@"savedbrand"];
    [userinfo setObject:saveimg forKey:@"savedbrandimg"];
    
    //推入下一界面
    ItemTypeContainViewController *viewbrand=[[ItemTypeContainViewController alloc]init];
    [self.navigationController pushViewController:viewbrand animated:YES];
    
}

//-------------------------------------------------------------------


-(instancetype)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrnil
{
    self =[super initWithNibName:nibNameOrNil bundle:nibBundleOrnil];
    if(self){
        //获取tabBarItem属性所指向的UITabBarItem对象
        UITabBarItem *tbi=self.tabBarItem;
        //设置UITabBarItem对象的标题
        tbi.title=@"搜索";
        //设置UITabBarItem对象的图像
        UIImage *i =[UIImage imageNamed:@"searchicon.png"];
        //将UIImage对象赋给标签的image属性
        tbi.image=i;
    }
    UINavigationItem *navitem=self.navigationItem;
    navitem.title=@"搜索";
    return self;
}



- (IBAction)itemsearch:(id)sender {
    NSString *textget=self.searchText.text;
    NSUserDefaults *userinfo = [NSUserDefaults standardUserDefaults];
    [userinfo setObject:textget forKey:@"savedsearchcontent"];
    
    SearchResultViewController *searchbegin=[[SearchResultViewController alloc]init];
    [self.navigationController pushViewController:searchbegin animated:YES];
    }
     


-(void)viewDidLoad
{
    
    self.searchText.placeholder = @"搜索商品";

    [self settable];
    
}


- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    [self.view endEditing:YES];
    
}

@end
