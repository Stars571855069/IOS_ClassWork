//
//  PrepareToLoginViewController.m
//  AimaiJiApplication
//
//  Created by DMT on 2018/12/21.
//  Copyright © 2018年 Stars. All rights reserved.
//

#import "PrepareToLoginViewController.h"
#import "LoginPageViewController.h"
#import "RegisterPageViewController.h"
#import "UserProfilePageViewController.h"
#import "SystemSettingPageViewController.h"

@interface PrepareToLoginViewController ()
@property (weak, nonatomic) IBOutlet UIButton *viewprofilebutton;
@property (weak, nonatomic) IBOutlet UIButton *changepicture;

@property (weak, nonatomic) IBOutlet UIView *loginview;
@property (weak, nonatomic) IBOutlet UIView *userprofileview;
@property (weak, nonatomic) IBOutlet UILabel *displayedusername;
@property (weak, nonatomic) IBOutlet UILabel *displayeduserinst;
@property (weak, nonatomic) IBOutlet UIImageView *displayuserphoto;

@property (weak, nonatomic) IBOutlet UIButton *collectionpagebutton;



@end

@implementation PrepareToLoginViewController





- (IBAction)buttonClick {
    
    UserProfilePageViewController *profileview=[[UserProfilePageViewController alloc]init];
    [self.navigationController pushViewController:profileview animated:YES];
}


-(instancetype)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrnil
{
    self =[super initWithNibName:nibNameOrNil bundle:nibBundleOrnil];
    if(self){
        //获取tabBarItem属性所指向的UITabBarItem对象
        UITabBarItem *tbi=self.tabBarItem;
        //设置UITabBarItem对象的标题
        tbi.title=@"我的";
        //设置UITabBarItem对象的图像
        UIImage *i =[UIImage imageNamed:@"Time.png"];
        //将UIImage对象赋给标签的image属性
        tbi.image=i;
    }
    UINavigationItem *navitem=self.navigationItem;
    navitem.title=@"我的";
    return self;
}

-(void)viewWillAppear:(BOOL)animated
{
    
//    [userinfo setObject:receivedusername forKey:@"savedusername"];
//    [userinfo setObject:receivedphotourl forKey:@"saveduserphoto"];
//    [userinfo setObject:receiveduserinst forKey:@"saveduserinst"];
    
    
    NSUserDefaults *userinfo = [NSUserDefaults standardUserDefaults];
    NSString *loginindex = [userinfo objectForKey:@"savedindex"];
    NSString *displayedusername = [userinfo objectForKey:@"savedusername"];
    //NSString *displayeduserinst = [userinfo objectForKey:@"saveduserinst"];
    NSString *displayeduserphoto = [userinfo objectForKey:@"saveduserphoto"];
    
    NSLog(@"%@",loginindex);
    if([loginindex intValue]!=1){
        self.userprofileview.hidden=true;
        self.loginview.hidden=false;
    }
    else{
        self.userprofileview.hidden=false;
        self.loginview.hidden=true;
        
        self.displayedusername.text=displayedusername;
        //self.displayeduserinst.text=displayeduserinst;
        [self.displayuserphoto setImage:[UIImage imageNamed:displayeduserphoto]];
        
//        UIImage *photoimage = [UIImage imageWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:displayeduserphoto]]];
//
//        NSLog(@"%@",displayeduserphoto);
//        self.displayuserphoto.image=photoimage;
    }
    
}
- (IBAction)logout:(id)sender {
    NSString *appDomain = [[NSBundle mainBundle] bundleIdentifier];
    [[NSUserDefaults standardUserDefaults] removePersistentDomainForName:appDomain];
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"提示" message:@"已退出登录" delegate:nil cancelButtonTitle:@"好的" otherButtonTitles:nil, nil];
    [alert show];
        self.userprofileview.hidden=true;
        self.loginview.hidden=false;
    
}



- (IBAction)viewRegisterPage {
    RegisterPageViewController *viewregister=[[RegisterPageViewController alloc]init];
    [self.navigationController pushViewController:viewregister animated:YES];
}
- (IBAction)viewLoginPage {
    LoginPageViewController *viewlogin=[[LoginPageViewController alloc]init];
    [self.navigationController pushViewController:viewlogin animated:YES];
}

@end
