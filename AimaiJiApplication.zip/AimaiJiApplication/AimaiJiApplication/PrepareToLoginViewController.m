//
//  PrepareToLoginViewController.m
//  AimaiJiApplication
//
//  Created by DMT on 2018/12/21.
//  Copyright © 2018年 Stars. All rights reserved.
//
#define kScreenWidth [UIScreen mainScreen].bounds.size.width
#define kScreenHeight [UIScreen mainScreen].bounds.size.height

#import "PrepareToLoginViewController.h"
#import "LoginPageViewController.h"
#import "RegisterPageViewController.h"
#import "UserProfilePageViewController.h"
#import "SystemSettingPageViewController.h"
#import "UserCommentTableViewCell.h"
#import "AddCommentPageViewController.h"
#import "AFNetworking.h"

@interface PrepareToLoginViewController ()
{
    NSArray * resultarray;
}
@property (weak, nonatomic) IBOutlet UIButton *viewprofilebutton;
@property (weak, nonatomic) IBOutlet UIButton *changepicture;

@property (weak, nonatomic) IBOutlet UIView *loginview;
@property (weak, nonatomic) IBOutlet UIView *userprofileview;
@property (weak, nonatomic) IBOutlet UILabel *displayedusername;
@property (weak, nonatomic) IBOutlet UILabel *displayeduserinst;
@property (weak, nonatomic) IBOutlet UIImageView *displayuserphoto;

@property (weak, nonatomic) IBOutlet UILabel *nocommentinfo;
@property (weak, nonatomic) IBOutlet UIScrollView *commentcontainer;
@property (weak, nonatomic) IBOutlet UITableView *tableView;


@property (weak, nonatomic) IBOutlet UIButton *collectionpagebutton;
@property (weak, nonatomic) IBOutlet UIButton *addcomment;



@end

@implementation PrepareToLoginViewController




#pragma mark - 进入个人信息
- (IBAction)buttonClick {
    
    UserProfilePageViewController *profileview=[[UserProfilePageViewController alloc]init];
    [self.navigationController pushViewController:profileview animated:YES];
}

#pragma mark - 属性设置
-(instancetype)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrnil
{
    self =[super initWithNibName:nibNameOrNil bundle:nibBundleOrnil];
    if(self){
        //获取tabBarItem属性所指向的UITabBarItem对象
        UITabBarItem *tbi=self.tabBarItem;
        //设置UITabBarItem对象的标题
        tbi.title=@"我的";
        //设置UITabBarItem对象的图像
        UIImage *i =[UIImage imageNamed:@"usericon.png"];
        //将UIImage对象赋给标签的image属性
        tbi.image=i;
    }
    UINavigationItem *navitem=self.navigationItem;
    navitem.title=@"我的";
    return self;
}

#pragma mark - 加载设置
-(void)viewWillAppear:(BOOL)animated
{
    
//    [userinfo setObject:receivedusername forKey:@"savedusername"];
//    [userinfo setObject:receivedphotourl forKey:@"saveduserphoto"];
//    [userinfo setObject:receiveduserinst forKey:@"saveduserinst"];
    
    
    NSUserDefaults *userinfo = [NSUserDefaults standardUserDefaults];
    NSString *loginindex = [userinfo objectForKey:@"savedindex"];
    NSString *displayedusername = [userinfo objectForKey:@"savedusername"];
    //NSString *displayeduserinst = [userinfo objectForKey:@"saveduserinst"];
    NSString *displayeduserphoto = [userinfo objectForKey:@"saveduserphoto"];
    
    NSLog(@"%@",loginindex);
    if([loginindex intValue]!=1){
        self.userprofileview.hidden=true;
        self.loginview.hidden=false;
    }
    else{
        self.userprofileview.hidden=false;
        self.loginview.hidden=true;
        
        self.displayedusername.text=displayedusername;
        //self.displayeduserinst.text=displayeduserinst;
        [self.displayuserphoto setImage:[UIImage imageNamed:displayeduserphoto]];
        
        //加载动态
        //============
        
        
        AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
        
        manager.requestSerializer = [AFJSONRequestSerializer serializer];
//        manager.responseSerializer.acceptableContentTypes = [NSSet setWithObjects:@"application/json", @"text/plain",@"text/html", nil];
        
        NSUserDefaults *userinfo = [NSUserDefaults standardUserDefaults];
        NSString *loginindex = [userinfo objectForKey:@"savedindex"];
        NSString *loginedusername = [userinfo objectForKey:@"savedusername"];
        
        NSLog(@"%@",loginindex);

            //
            NSString *requestusername=loginedusername;
            
            NSDictionary *paramDict = @{
                                        @"apicode":@"viewcomment",
                                        @"args":@{
                                                @"username":requestusername
                                                }
                                        };
            
            [manager POST:@"http://localhost:3000/Find" parameters:paramDict progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                
                NSLog(@"%@---%@",[responseObject class],responseObject);
                NSString *code=responseObject[@"data"][@"code"];
                int returncode = [code intValue];
                NSLog(@"%d",returncode);
                
                if (returncode!=0){
                    if(returncode!=2){
                        self.nocommentinfo.hidden=false;
                        self.commentcontainer.hidden=true;
                    }
                    else if(returncode==2){
                        NSLog(@"读取评论内容成功");
                        self.nocommentinfo.hidden=true;
                        self.commentcontainer.hidden=false;
                        self->resultarray=responseObject[@"data"][@"commentlist"];
                        [self.tableView reloadData];
                }
                else{
                    NSLog(@"读取失败");
                }
            }
                
            } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                NSLog(@"请求失败--%@",error);
            }];

        //——————————————————————————————————————————————————————————————————————————
       }
}
//-----------------------------------------------------------------------------
-(void)settable{
    //初始化tableView,并给tableView设置frame以及样式
    float tarbarheight=[[UIApplication sharedApplication] statusBarFrame].size.height;
    //CGRect *height=CGRectMake(0, 0, 375, kScreenHeight-tarbarheight*2);
    CGRect scrollsize=CGRectMake(0,0, 375, kScreenHeight-tarbarheight*2);
    CGRect mainSize=scrollsize;
    mainSize.size.height*=0.75;
    
    
    //self.tableView = [[UITableView alloc] initWithFrame:[UIScreen mainScreen].bounds style:UITableViewStylePlain];
    self.tableView.contentSize=mainSize.size;
    
    //遵守代理和数据源(因为要用到代理和数据源方法)
    //self.edgesForExtendedLayout = UIRectEdgeNone;
    //self.tableView.
    //self.view.backgroundColor = [UIColor whiteColor];
    self.tableView.delegate = (id)self;
    self.tableView.dataSource = (id)self;
    //添加到ViewController的视图中
    
    [self.commentcontainer addSubview:self.tableView];
    
    
    //self.tableView.frame=[CGRectMake(0, 30, 375, kScreenHeight-tarbarheight-30-10)];
    self.commentcontainer.backgroundColor=[UIColor colorWithRed:250.0/255.0 green:251.0/255.0 blue:255.0/255.0 alpha:1];
    self.tableView.backgroundColor=[UIColor colorWithRed:250.0/255.0 green:251.0/255.0 blue:255.0/255.0 alpha:1];
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self->resultarray.count;
}


//点击事件
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    NSLog(@"选中了第%li个cell", (long)indexPath.row);
    //将cell传递的数据保存在userdefault中，在对应页面加载时调取这些数据
    NSUserDefaults *userinfo = [NSUserDefaults standardUserDefaults];
    NSString *commentname = self->resultarray[indexPath.row][@"itemname"];
    [userinfo setObject:commentname forKey:@"collectionname"];
    
    //推入下一界面
    //AddCommentPageViewController *addcomment=[[AddCommentPageViewController alloc]init];
    //[self.navigationController pushViewController:addcomment animated:YES];
    
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    //指定cell的重用标识符
    static NSString *reuseIdentifier = @"MyCollectionTableViewCell";
    //去缓存池找名叫reuseIdentifier的cell
    UserCommentTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:reuseIdentifier];
    //如果缓存池中没有,那么创建一个新的cell
    if (!cell) {
        cell = [UserCommentTableViewCell UserCommentTableViewCell];
    }
    //数据重载
    //载入商品名称
    cell.commentusername.text = self->resultarray[indexPath.row][@"commentuser"];

    //NSString *price = [NSString stringWithFormat:@"%@",self->resultarray[indexPath.row][@"itemprice"]];
    
    //格式化日期
    //NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    // 设置日期格式
    //[formatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    // 获取当前日期
    //NSDate *currentDate = [NSDate date];
    //NSString *formattedDateString = [formatter stringFromDate:self->resultarray[indexPath.row][@"commentdate"]];

    //NSLog(@"%@",formattedDateString);
    NSString *rawdate=self->resultarray[indexPath.row][@"commentdate"];
    //NSString *formatteddate = [rawdate substringToIndex:10];//
    NSString *formattedtime = [rawdate substringWithRange:NSMakeRange(11,5)];
    
    //NSString *display = [formatteddate stringByAppendingString: formattedtime];
    
    cell.commentdate.text = formattedtime;
    cell.comment.text=self->resultarray[indexPath.row][@"comment"];
    NSString *commentid = [NSString stringWithFormat:@"%@",self->resultarray[indexPath.row][@"commentid"]];

    
    cell.hiddenid.text=commentid;
    [cell.commentuserphoto setImage:[UIImage imageNamed:self->resultarray[indexPath.row][@"commentuserphoto"]]];
    //返回当前cell
    return cell;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 100;
}

//-----------------------------------------------------------------------------

             
- (IBAction)logout:(id)sender {
    NSString *appDomain = [[NSBundle mainBundle] bundleIdentifier];
    [[NSUserDefaults standardUserDefaults] removePersistentDomainForName:appDomain];
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"提示" message:@"已退出登录" delegate:nil cancelButtonTitle:@"好的" otherButtonTitles:nil, nil];
    [alert show];
        self.userprofileview.hidden=true;
        self.loginview.hidden=false;
    
}

-(void)viewDidLoad{
    [self settable];
}
- (IBAction)viewaddingcommentpage:(id)sender {
    AddCommentPageViewController *viewaddingcommentpage=[[AddCommentPageViewController alloc]init];
    [self.navigationController pushViewController:viewaddingcommentpage animated:YES];
    
}

- (IBAction)viewRegisterPage {
    RegisterPageViewController *viewregister=[[RegisterPageViewController alloc]init];
    [self.navigationController pushViewController:viewregister animated:YES];
}
- (IBAction)viewLoginPage {
    LoginPageViewController *viewlogin=[[LoginPageViewController alloc]init];
    [self.navigationController pushViewController:viewlogin animated:YES];
}

@end
