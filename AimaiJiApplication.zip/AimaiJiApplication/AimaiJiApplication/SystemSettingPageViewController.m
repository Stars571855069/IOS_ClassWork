//
//  SystemSettingPageViewController.m
//  AimaiJiApplication
//
//  Created by DMT on 2018/11/29.
//  Copyright © 2018年 Stars. All rights reserved.
//

#import "SystemSettingPageViewController.h"
#import "GeneralSettingViewController.h"

@interface SystemSettingPageViewController ()
@property (weak, nonatomic) IBOutlet UIButton *GeneralPageView;

@end

@implementation SystemSettingPageViewController

-(instancetype)init
{
    
    UINavigationItem *navitem=self.navigationItem;
    navitem.title=@"设置";
    
    return self;
}
- (IBAction)viewGengralSettingPage {
    GeneralSettingViewController *viewgeneralsetting=[[GeneralSettingViewController alloc]init];
    [self.navigationController pushViewController:viewgeneralsetting animated:YES];
}

@end
