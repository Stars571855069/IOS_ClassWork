//
//  ItemTypeContainViewController.h
//  AimaiJiApplication
//
//  Created by DMT on 2019/1/5.
//  Copyright © 2019年 Stars. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ItemTypeContainViewController : UIViewController

@end
