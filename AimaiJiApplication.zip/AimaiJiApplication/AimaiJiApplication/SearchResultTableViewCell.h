//
//  SearchResultTableViewCell.h
//  AimaiJiApplication
//
//  Created by DMT on 2018/12/27.
//  Copyright © 2018年 Stars. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SearchResultTableViewCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UIView *searchresultcell;
@property (weak, nonatomic) IBOutlet UIImageView *searchresultphoto;
@property (weak, nonatomic) IBOutlet UILabel *searchresultname;
@property (weak, nonatomic) IBOutlet UIButton *searchresultbutton;

+(instancetype)SearchResultTableViewCell;
@end
