//
//  MyCollectionPageViewController.m
//  AimaiJiApplication
//
//  Created by DMT on 2018/11/29.
//  Copyright © 2018年 Stars. All rights reserved.
//
#define kScreenWidth [UIScreen mainScreen].bounds.size.width
#define kScreenHeight [UIScreen mainScreen].bounds.size.height

#import "MyCollectionPageViewController.h"
#import "ItemShopPageViewController.h"
#import "MyCollectionTableViewCell.h"
#import "AFNetworking.h"
#import "TypeDetailViewController.h"

@interface MyCollectionPageViewController ()
{
    NSArray * resultarray;
}

@property (weak, nonatomic) IBOutlet UILabel *viewitemshoppage1;
@property (weak, nonatomic) IBOutlet UILabel *viewitemshoppage2;
@property (weak, nonatomic) IBOutlet UIView *myCollectioncontainer;
@property (strong, nonatomic) IBOutlet UITableView *tableView;
@property (weak, nonatomic) IBOutlet UILabel *logginginfo;

@end

@implementation MyCollectionPageViewController

-(instancetype)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrnil
{
    self =[super initWithNibName:nibNameOrNil bundle:nibBundleOrnil];
    if(self){
        //获取tabBarItem属性所指向的UITabBarItem对象
        UITabBarItem *tbi=self.tabBarItem;
        //设置UITabBarItem对象的标题
        tbi.title=@"收藏";
        //设置UITabBarItem对象的图像
        UIImage *i =[UIImage imageNamed:@"collectionicon.png"];
        //将UIImage对象赋给标签的image属性
        tbi.image=i;
    }
    UINavigationItem *navitem=self.navigationItem;
    navitem.title=@"收藏夹";
    return self;
}
- (IBAction)viewItemshoppage {
    ItemShopPageViewController *itemshoppage=[[ItemShopPageViewController alloc]init];
    [self.navigationController pushViewController:itemshoppage animated:YES];
}


//-----------------------------------------------------------------------------
-(void)settable{
    //初始化tableView,并给tableView设置frame以及样式
    float tarbarheight=[[UIApplication sharedApplication] statusBarFrame].size.height;
    //CGRect *height=CGRectMake(0, 0, 375, kScreenHeight-tarbarheight*2);
    CGRect scrollsize=CGRectMake(0,0, 375, kScreenHeight-tarbarheight*2);
    CGRect mainSize=scrollsize;
    mainSize.size.height*=0.75;
    
    
    //self.tableView = [[UITableView alloc] initWithFrame:[UIScreen mainScreen].bounds style:UITableViewStylePlain];
    self.tableView.contentSize=mainSize.size;
    
    //遵守代理和数据源(因为要用到代理和数据源方法)
    //self.edgesForExtendedLayout = UIRectEdgeNone;
    //self.tableView.
    //self.view.backgroundColor = [UIColor whiteColor];
    self.tableView.delegate = (id)self;
    self.tableView.dataSource = (id)self;
    //添加到ViewController的视图中
   
    [self.myCollectioncontainer addSubview:self.tableView];
    
    
    //self.tableView.frame=[CGRectMake(0, 30, 375, kScreenHeight-tarbarheight-30-10)];
    self.myCollectioncontainer.backgroundColor=[UIColor colorWithRed:250.0/255.0 green:251.0/255.0 blue:255.0/255.0 alpha:1];
    self.tableView.backgroundColor=[UIColor colorWithRed:250.0/255.0 green:251.0/255.0 blue:255.0/255.0 alpha:1];
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self->resultarray.count;
}


//点击事件
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    NSLog(@"选中了第%li个cell", (long)indexPath.row);
    //将cell传递的数据保存在userdefault中，在对应页面加载时调取这些数据
    NSUserDefaults *userinfo = [NSUserDefaults standardUserDefaults];
    NSString *collectionname = self->resultarray[indexPath.row][@"itemname"];
    [userinfo setObject:collectionname forKey:@"collectionname"];
    
    //推入下一界面
    TypeDetailViewController *viewdetail=[[TypeDetailViewController alloc]init];
    [self.navigationController pushViewController:viewdetail animated:YES];
    
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    //指定cell的重用标识符
    static NSString *reuseIdentifier = @"MyCollectionTableViewCell";
    //去缓存池找名叫reuseIdentifier的cell
    MyCollectionTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:reuseIdentifier];
    //如果缓存池中没有,那么创建一个新的cell
    if (!cell) {
        cell = [MyCollectionTableViewCell MyCollectionTableViewCell];
    }
    //数据重载
    //载入商品名称
    cell.coname.text = self->resultarray[indexPath.row][@"itemname"];
    //将价格数字转化为字符串，载入商品字符串
    NSString *price = [NSString stringWithFormat:@"%@",self->resultarray[indexPath.row][@"itemprice"]];
    cell.coprice.text = price;
    //载入商品图片
    [cell.cophoto setImage:[UIImage imageNamed:self->resultarray[indexPath.row][@"itemimageurl"]]];
    //返回当前cell
    return cell;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 125;
}

-(void)viewWillAppear:(BOOL)animated{

    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];

    manager.requestSerializer = [AFJSONRequestSerializer serializer];

    
    NSUserDefaults *userinfo = [NSUserDefaults standardUserDefaults];
    NSString *loginindex = [userinfo objectForKey:@"savedindex"];
    NSString *loginedusername = [userinfo objectForKey:@"savedusername"];
    
    NSLog(@"%@",loginindex);
    if([loginindex intValue]!=1){
        //必须登录才可查看
        self.myCollectioncontainer.hidden=true;
        self.logginginfo.hidden=false;
        self.logginginfo.text=@"登录后查看更多信息";
    }
    else{
        self.myCollectioncontainer.hidden=false;
        self.logginginfo.hidden=true;
//
        NSString *postusername=loginedusername;
        
        NSDictionary *paramDict = @{
                                    @"apicode":@"viewcollection",
                                    @"args":@{
                                            @"username":postusername
                                            }
                                    };
        
        [manager POST:@"http://localhost:3000/Cart" parameters:paramDict progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
            
            NSLog(@"%@---%@",[responseObject class],responseObject);
            NSString *code=responseObject[@"data"][@"code"];
            int returncode = [code intValue];
            NSLog(@"%d",returncode);
            
            if (returncode!=0){
                if(returncode!=2){
                    self.logginginfo.text=@"你的收藏夹内还没有物品";
                    self.logginginfo.hidden=false;
                    self.myCollectioncontainer.hidden=true;
                }
                else if(returncode==2){
                    NSLog(@"读取收藏成功");
                    self.logginginfo.hidden=true;
                    self.myCollectioncontainer.hidden=false;
                    self->resultarray=responseObject[@"data"][@"collectionlist"];}
                    [self.tableView reloadData];
            }
            else{
                NSLog(@"读取失败");
            }
            
            
        } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
            NSLog(@"请求失败--%@",error);
        }];
    }
    
    
    
    
    
};


-(void)viewDidLoad{
    [self settable];
}


@end
