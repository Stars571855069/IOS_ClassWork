//
//  MyCollectionPageViewController.m
//  AimaiJiApplication
//
//  Created by DMT on 2018/11/29.
//  Copyright © 2018年 Stars. All rights reserved.
//

#import "MyCollectionPageViewController.h"
#import "ItemShopPageViewController.h"
#import "MyCollectionTableViewCell.h"
#import "AFNetworking.h"

@interface MyCollectionPageViewController ()
{
    NSArray * resultarray;
}

@property (weak, nonatomic) IBOutlet UILabel *viewitemshoppage1;
@property (weak, nonatomic) IBOutlet UILabel *viewitemshoppage2;
@property (weak, nonatomic) IBOutlet UIView *myCollectioncontainer;
@property (strong, nonatomic) IBOutlet UITableView *tableView;
@property (weak, nonatomic) IBOutlet UILabel *logginginfo;

@end

@implementation MyCollectionPageViewController

-(instancetype)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrnil
{
    self =[super initWithNibName:nibNameOrNil bundle:nibBundleOrnil];
    if(self){
        //获取tabBarItem属性所指向的UITabBarItem对象
        UITabBarItem *tbi=self.tabBarItem;
        //设置UITabBarItem对象的标题
        tbi.title=@"收藏";
        //设置UITabBarItem对象的图像
        UIImage *i =[UIImage imageNamed:@"Hypno.png"];
        //将UIImage对象赋给标签的image属性
        tbi.image=i;
    }
    UINavigationItem *navitem=self.navigationItem;
    navitem.title=@"收藏夹";
    return self;
}
- (IBAction)viewItemshoppage {
    ItemShopPageViewController *itemshoppage=[[ItemShopPageViewController alloc]init];
    [self.navigationController pushViewController:itemshoppage animated:YES];
}


//-----------------------------------------------------------------------------
-(void)settable{
    //初始化tableView,并给tableView设置frame以及样式
    float tarbarheight=[[UIApplication sharedApplication] statusBarFrame].size.height;
    //self.tablecontainer=[[UIView alloc]initWithFrame:CGRectMake(0, 0, 375, kScreenHeight-tarbarheight*2)];
    self.tableView = [[UITableView alloc] initWithFrame:[UIScreen mainScreen].bounds style:UITableViewStylePlain];
    //遵守代理和数据源(因为要用到代理和数据源方法)
    self.tableView.delegate = (id)self;
    self.tableView.dataSource = (id)self;
    //添加到ViewController的视图中
    [self.myCollectioncontainer addSubview:self.tableView];
    
    
    //self.tableView.frame=[CGRectMake(0, 30, 375, kScreenHeight-tarbarheight-30-10)];
    self.myCollectioncontainer.backgroundColor=[UIColor colorWithRed:250.0/255.0 green:251.0/255.0 blue:255.0/255.0 alpha:1];
    self.tableView.backgroundColor=[UIColor colorWithRed:250.0/255.0 green:251.0/255.0 blue:255.0/255.0 alpha:1];
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self->resultarray.count;
}


//点击事件
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    NSLog(@"选中了第%li个cell", (long)indexPath.row);
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    //指定cell的重用标识符
    static NSString *reuseIdentifier = @"MyCollectionTableViewCell";
    //去缓存池找名叫reuseIdentifier的cell
    MyCollectionTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:reuseIdentifier];
    //如果缓存池中没有,那么创建一个新的cell
    if (!cell) {
        cell = [MyCollectionTableViewCell MyCollectionTableViewCell];
    }
    //数据重载
    cell.coname.text = self->resultarray[indexPath.row][@"itemname"];
    NSString *imageurl= self->resultarray[indexPath.row][@"itemimageurl"];
    UIImage *itemimage = [UIImage imageWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:imageurl]]];
    cell.cophoto.image=itemimage;

    //返回当前cell
    return cell;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 125;
}

-(void)viewWillAppear:(BOOL)animated{

    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];

    manager.requestSerializer = [AFJSONRequestSerializer serializer];

    
    NSUserDefaults *userinfo = [NSUserDefaults standardUserDefaults];
    NSString *loginindex = [userinfo objectForKey:@"savedindex"];
    NSString *loginedusername = [userinfo objectForKey:@"savedusername"];
    
    NSLog(@"%@",loginindex);
    if([loginindex intValue]!=1){
        self.myCollectioncontainer.hidden=true;
        self.logginginfo.hidden=false;
        self.logginginfo.text=@"登录后查看更多信息";
    }
    else{
        self.myCollectioncontainer.hidden=false;
        self.logginginfo.hidden=true;
//
        NSString *postusername=loginedusername;
        
        NSDictionary *paramDict = @{
                                    @"apicode":@"viewcollection",
                                    @"args":@{
                                            @"username":postusername
                                            }
                                    };
        
        [manager POST:@"http://localhost:3000/Cart" parameters:paramDict progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
            
            NSLog(@"%@---%@",[responseObject class],responseObject);
            NSString *code=responseObject[@"data"][@"code"];
            int returncode = [code intValue];
            NSLog(@"%d",returncode);
            
            if (returncode!=0){
                if(returncode!=2){
                    self.logginginfo.text=@"你的收藏夹内还没有物品";
                    self.logginginfo.hidden=false;
                    self.myCollectioncontainer.hidden=true;
                }
                else if(returncode==2){
                    NSLog(@"读取收藏成功");
                    self.logginginfo.hidden=true;
                    self.myCollectioncontainer.hidden=false;
                    self->resultarray=responseObject[@"data"][@"collectionlist"];}
                    [self.tableView reloadData];
            }
            else{
                NSLog(@"读取失败");
            }
            
            
        } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
            NSLog(@"请求失败--%@",error);
        }];
    }
    
    
    
    
    
};


-(void)viewDidLoad{
    [self settable];
}


@end
