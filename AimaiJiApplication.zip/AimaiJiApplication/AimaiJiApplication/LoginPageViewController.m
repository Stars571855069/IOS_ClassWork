//
//  LoginPageViewController.m
//  AimaiJiApplication
//
//  Created by DMT on 2018/11/29.
//  Copyright © 2018年 Stars. All rights reserved.
//

#import "LoginPageViewController.h"
#import "AFNetworking.h"
#import "MyProfileViewController.h"

//#import <UIalert>

@interface LoginPageViewController ()
@property (weak, nonatomic) IBOutlet UIButton *loginbutton;
@property (weak, nonatomic) IBOutlet UITextField *loginusername;
@property (weak, nonatomic) IBOutlet UITextField *loginpassword;

@end

@implementation LoginPageViewController

-(instancetype)init
{
    
    UINavigationItem *navitem=self.navigationItem;
    navitem.title=@"登录";
    
    return self;
}




- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    [self.view endEditing:YES];
    
}
- (IBAction)loginaction {
    
    //1.创建会话管理者
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    
    //设置请求数据格式自动转换为JSON
    manager.requestSerializer = [AFJSONRequestSerializer serializer];
    
    // manager.responseSerializer.acceptableContentTypes = [NSSet setWithObjects:@"application/json", @"text/plain",@"text/html", nil];
    //
    NSDictionary *paramDict = @{
                                @"apicode":@"Login",
                                @"args":@{
                                        @"username":_loginusername.text,
                                        @"password":_loginpassword.text,
                                        }
                                
                                };
    //2.发送POST请求
    /*
     第一个参数:请求路径(不包含参数).NSString
     第二个参数:字典(发送给服务器的数据~参数)
     第三个参数:progress 进度回调
     第四个参数:success 成功回调
     task:请求任务
     responseObject:响应体信息(JSON--->OC对象)
     第五个参数:failure 失败回调
     error:错误信息
     响应头:task.response
     */
    [manager POST:@"http://localhost:3000/login" parameters:paramDict progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        
        NSLog(@"%@---%@",[responseObject class],responseObject);
        if (responseObject[@"data"]!=nil){
            NSLog(@"%@",@"登录成功");
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"提示" message:@"登录成功" delegate:nil cancelButtonTitle:@"好的" otherButtonTitles:nil, nil];
            [alert show];

            NSString *receivedindex = responseObject[@"data"][@"sendindex"];
            NSString *receivedusername = responseObject[@"data"][@"sendusername"];
            NSString *receivedphotourl = responseObject[@"data"][@"senduserphoto"];
            NSString *receiveduserinst = responseObject[@"data"][@"senduserinst"];



            NSUserDefaults *userinfo = [NSUserDefaults standardUserDefaults];
            [userinfo setObject:receivedindex forKey:@"savedindex"];
            [userinfo setObject:receivedusername forKey:@"savedusername"];
            [userinfo setObject:receivedphotourl forKey:@"saveduserphoto"];
            [userinfo setObject:receiveduserinst forKey:@"saveduserinst"];


            NSLog(@"%@------%@------%@",receivedusername,receivedphotourl,receiveduserinst);

            //MyProfileViewController *backtoprofile=[[MyProfileViewController alloc]init];
            [self.navigationController popViewControllerAnimated:YES];

        }else{
            NSLog(@"%@",@"用户名或密码错误");
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"警告" message:@"用户名或者密码错误" delegate:nil cancelButtonTitle:@"好的" otherButtonTitles:nil, nil];
            [alert show];
        }
        
        
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        NSLog(@"请求失败--%@",error);
    }];
}

@end
