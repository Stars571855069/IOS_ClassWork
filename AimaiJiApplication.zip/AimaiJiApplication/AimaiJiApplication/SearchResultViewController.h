//
//  SearchResultViewController.h
//  AimaiJiApplication
//
//  Created by DMT on 2018/12/27.
//  Copyright © 2018年 Stars. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SearchResultViewController : UIViewController



@end
