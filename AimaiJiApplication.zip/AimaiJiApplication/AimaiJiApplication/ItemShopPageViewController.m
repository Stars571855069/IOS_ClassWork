//
//  ItemShopPageViewController.m
//  AimaiJiApplication
//
//  Created by DMT on 2018/11/29.
//  Copyright © 2018年 Stars. All rights reserved.
//

#import "ItemShopPageViewController.h"

@interface ItemShopPageViewController ()
@property (weak, nonatomic) IBOutlet UIImageView *itemimage;
@property (weak, nonatomic) IBOutlet UILabel *itemname;
@property (weak, nonatomic) IBOutlet UILabel *itemprice;
@property (weak, nonatomic) IBOutlet UITextView *iteminfo;
@property (weak, nonatomic) IBOutlet UIView *itemshoppageContainerView;
@property (strong, nonatomic) IBOutlet UIScrollView *itemshoppageScrollView;

@end

@implementation ItemShopPageViewController

-(instancetype)init
{
    
    UINavigationItem *navitem=self.navigationItem;
    navitem.title=@"商城";
    
    return self;
}
-(void)viewDidLoad
{
    
    self.itemimage.image = [UIImage imageNamed:@"iphone.png"];
    self.itemimage.contentMode = UIViewContentModeScaleToFill;
    
    [super viewDidLoad];
    CGRect scrollsize=CGRectMake(0,0, 375, 675);
    CGRect mainSize=scrollsize;
    mainSize.size.height*=1.6;
    self.itemshoppageScrollView.frame=scrollsize;
    self.itemshoppageScrollView.backgroundColor=[UIColor colorWithRed:250.0/255.0 green:251.0/255.0 blue:255.0/255.0 alpha:1];
    self.itemshoppageScrollView.contentSize = mainSize.size;
    [self.itemshoppageScrollView addSubview:self.itemshoppageContainerView];
    
    
    
    NSLog(@"ShopPageScrollView Activated.");
}

@end
