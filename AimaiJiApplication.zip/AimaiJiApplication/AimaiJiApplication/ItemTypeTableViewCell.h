//
//  ItemTypeTableViewCell.h
//  AimaiJiApplication
//
//  Created by DMT on 2018/12/27.
//  Copyright © 2018年 Stars. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ItemTypeTableViewCell : UITableViewCell
@property (strong, nonatomic) IBOutlet ItemTypeTableViewCell *Typecell;
@property (weak, nonatomic) IBOutlet UIImageView *Typecellphoto;
@property (weak, nonatomic) IBOutlet UILabel *Typecellname;
@property (weak, nonatomic) IBOutlet UILabel *Typecellinst;
@property (weak, nonatomic) IBOutlet UIButton *Typeclick;


+(instancetype)ItemTypeTableViewCell;

@end
