//
//  ItemTypeContainViewController.m
//  AimaiJiApplication
//
//  Created by DMT on 2019/1/5.
//  Copyright © 2019年 Stars. All rights reserved.
//

#import "ItemTypeContainViewController.h"
#import "MyCollectionTableViewCell.h"
#import "TypeDetailViewController.h"
#import "AFNetworking.h"

@interface ItemTypeContainViewController ()
{
    NSArray * resultarray;
}

@property (weak, nonatomic) IBOutlet UIImageView *brandimage;
@property (strong, nonatomic) IBOutlet UITableView *tableView;
@property (weak, nonatomic) IBOutlet UIScrollView *typelistcontainer;

@property (weak, nonatomic) IBOutlet UILabel *resultinfo;

@end

@implementation ItemTypeContainViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self settable];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


-(void)viewWillAppear:(BOOL)animated{
//        CGRect scrollsize=CGRectMake(0,0, 375, 1350);
//        CGRect mainSize=scrollsize;
//        mainSize.size.height*=1;
//        self.typelistcontainer.frame=scrollsize;
//    
//        self.typelistcontainer.contentSize = mainSize.size;
//        [self.typelistcontainer addSubview:self.tableView];
//        [self.view addSubview:self.typelistcontainer];
    
        //1.创建会话管理者
        AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
        
        //设置请求数据格式自动转换为JSON
        manager.requestSerializer = [AFJSONRequestSerializer serializer];
    
        NSUserDefaults *userinfo = [NSUserDefaults standardUserDefaults];
        NSString *brand = [userinfo objectForKey:@"savedbrand"];
        NSString *brandimage = [userinfo objectForKey:@"savedbrandimg"];
    
    
        [self.brandimage setImage:[UIImage imageNamed:brandimage]];
        NSDictionary *paramDict = @{
                                @"apicode":@"typecontain",
                                @"args":@{
                                        @"targetbrand":brand
                                        }
                                };
    
        [manager POST:@"http://localhost:3000/ShopItemType" parameters:paramDict progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
            
            NSLog(@"%@---%@",[responseObject class],responseObject);
            NSString *code=responseObject[@"data"][@"code"];
            int returncode = [code intValue];
            NSLog(@"%d",returncode);
            
            if (returncode!=0){
                if(returncode!=2){
                    self.resultinfo.hidden=false;
                    self.typelistcontainer.hidden=true;
                }
                else if(returncode==2){
                    NSLog(@"读取品牌商品成功");
                    self.resultinfo.hidden=true;
                    self.typelistcontainer.hidden=false;
                    self->resultarray=responseObject[@"data"][@"typeitemlist"];}
                    [self.tableView reloadData];
            }
            else if(returncode==1){
                NSLog(@"未找到结果");
                self.resultinfo.hidden=false;
                self.typelistcontainer.hidden=true;
            }
            
            
        } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
            NSLog(@"请求失败--%@",error);
        }];
    
}





//-----------------------------------------------------------------------------
-(void)settable{
    //初始化tableView,并给tableView设置frame以及样式
    //float tarbarheight=[[UIApplication sharedApplication] statusBarFrame].size.height;
    //self.searchresultcontainer=[[UIView alloc]initWithFrame:CGRectMake(0, 0, 375, kScreenHeight-tarbarheight*2)];
    
    //self.tableView = [[UITableView alloc] initWithFrame:[UIScreen mainScreen].bounds style:UITableViewStylePlain];
    //遵守代理和数据源(因为要用到代理和数据源方法)
    self.tableView.delegate = (id)self;
    self.tableView.dataSource = (id)self;
    //添加到ViewController的视图中
    [self.typelistcontainer addSubview:self.tableView];
    
    
    //self.tableView.frame=[CGRectMake(0, 30, 375, kScreenHeight-tarbarheight-30-10)];
    //self.searchresultcontainer.backgroundColor=[UIColor colorWithRed:250.0/255.0 green:251.0/255.0 blue:255.0/255.0 alpha:1];
    self.tableView.backgroundColor=[UIColor colorWithRed:250.0/255.0 green:251.0/255.0 blue:255.0/255.0 alpha:1];
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self->resultarray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    //指定cell的重用标识符
    static NSString *reuseIdentifier = @"SearchResultTableViewCell";
    //去缓存池找名叫reuseIdentifier的cell
    MyCollectionTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:reuseIdentifier];
    //如果缓存池中没有,那么创建一个新的cell
    if (!cell) {
        cell = [MyCollectionTableViewCell MyCollectionTableViewCell];
    }
    //数据重载
    //载入商品名称
    cell.coname.text = self->resultarray[indexPath.row][@"itemname"];
    //将价格数字转化为字符串，载入商品字符串
    NSString *price = [NSString stringWithFormat:@"%@",self->resultarray[indexPath.row][@"itemprice"]];
    cell.coprice.text = price;
    //载入商品图片
    [cell.cophoto setImage:[UIImage imageNamed:self->resultarray[indexPath.row][@"itemimageurl"]]];
    //返回当前cell
    return cell;
//}
//    cell.searchresultname.text = self->resultarray[indexPath.row][@"itemname"];
//    //cell.searchresultphoto.image = [UIImage imageNamed:@"appleicon.png"];
//    [cell.searchresultphoto setImage:[UIImage imageNamed:self->resultarray[indexPath.row][@"itemimageurl"]]];
//    
//    //返回当前cell
//    return cell;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 125;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    NSLog(@"选中了第%li个cell", (long)indexPath.row);
    
    //将cell传递的数据保存在userdefault中，在对应页面加载时调取这些数据
    NSUserDefaults *userinfo = [NSUserDefaults standardUserDefaults];
    NSString *itemname = self->resultarray[indexPath.row][@"itemname"];
    [userinfo setObject:itemname forKey:@"collectionname"];
    
    //推入下一界面
    TypeDetailViewController *viewdetail=[[TypeDetailViewController alloc]init];
    [self.navigationController pushViewController:viewdetail animated:YES];
    
}


-(instancetype)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrnil
{
    self =[super initWithNibName:nibNameOrNil bundle:nibBundleOrnil];
    
    NSUserDefaults *userinfo = [NSUserDefaults standardUserDefaults];
    NSString *brand = [userinfo objectForKey:@"savedbrand"];
    
    UINavigationItem *navitem=self.navigationItem;
    navitem.title=brand;
    return self;
}

@end
