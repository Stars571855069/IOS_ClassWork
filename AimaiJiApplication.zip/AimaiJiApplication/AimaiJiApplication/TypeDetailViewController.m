//
//  TypeDetailViewController.m
//  AimaiJiApplication
//
//  Created by DMT on 2018/11/29.
//  Copyright © 2018年 Stars. All rights reserved.
//

#import "TypeDetailViewController.h"
#import "SearchItemViewController.h"

@interface TypeDetailViewController ()

@property (weak, nonatomic) IBOutlet UITextField *typenameField;
@property (weak, nonatomic) IBOutlet UITextView *typeinfoField;
@property (weak, nonatomic) IBOutlet UIImageView *typeimageField;
@property (strong, nonatomic) IBOutlet UIScrollView *Tscrollview;
@property (weak, nonatomic) IBOutlet UIView *containerView;

@end

@implementation TypeDetailViewController

-(instancetype)init
{
    
    UINavigationItem *navitem=self.navigationItem;
    navitem.title=@"产品详情";
    
    return self;
    
    
}

-(void)viewDidLoad
{
    [super viewDidLoad];
    CGRect scrollsize=CGRectMake(0,0, 375, 675);
    CGRect mainSize=scrollsize;
    mainSize.size.height*=1.5;
    self.Tscrollview.frame=scrollsize;
    self.Tscrollview.backgroundColor=[UIColor colorWithRed:250.0/255.0 green:251.0/255.0 blue:255.0/255.0 alpha:1];
    self.Tscrollview.contentSize = mainSize.size;
    [self.Tscrollview addSubview:self.containerView];
    
    
    //self.Tscrollview=[[UIScrollView alloc]initWithFrame:CGRectMake(0, 0, 320 , 300)];
    //[self.view addSubview:homeMainScrollView];
//    scrollView.frame=scrollsize;
//    self.TscrollView addSubview:_Tscrollview];
//    scrollView.scrollEnabled = YES;
//    scrollView.showsVerticalScrollIndicator=YES;
//    self.view addSubview:self.Tscrollview;
//    scrollView.contentSize = mainSize.size;
    NSLog(@"ScrollView Activated.");
    
}
@end
