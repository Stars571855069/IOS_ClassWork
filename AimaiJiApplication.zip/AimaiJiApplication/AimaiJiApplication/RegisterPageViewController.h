//
//  RegisterPageViewController.h
//  AimaiJiApplication
//
//  Created by DMT on 2018/11/29.
//  Copyright © 2018年 Stars. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RegisterPageViewController : UIViewController

@end
