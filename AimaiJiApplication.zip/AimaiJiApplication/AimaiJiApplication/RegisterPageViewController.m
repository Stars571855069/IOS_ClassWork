//
//  RegisterPageViewController.m
//  AimaiJiApplication
//
//  Created by DMT on 2018/11/29.
//  Copyright © 2018年 Stars. All rights reserved.
//

#import "RegisterPageViewController.h"
#import "AFNetworking.h"

@interface RegisterPageViewController ()
@property (weak, nonatomic) IBOutlet UITextField *regusername;
@property (weak, nonatomic) IBOutlet UIButton *registerbutton;
@property (weak, nonatomic) IBOutlet UITextField *regpassword;

@end

@implementation RegisterPageViewController

-(instancetype)init
{
    
    UINavigationItem *navitem=self.navigationItem;
    navitem.title=@"注册";
    
    return self;
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    [self.view endEditing:YES];
    
}
- (IBAction)registaction:(id)sender {
    
    //1.创建会话管理者
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    
    //设置请求数据格式自动转换为JSON
    manager.requestSerializer = [AFJSONRequestSerializer serializer];
    
    // manager.responseSerializer.acceptableContentTypes = [NSSet setWithObjects:@"application/json", @"text/plain",@"text/html", nil];
    //
    NSDictionary *paramDict = @{
                                @"apicode":@"register",
                                @"args":@{
                                        @"regusername":self.regusername.text,
                                        @"regpassword":self.regpassword.text,
                                        }
                                
                                };
    
    [manager POST:@"http://localhost:3000/Register" parameters:paramDict progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        
        NSLog(@"%@---%@",[responseObject class],responseObject);
        NSString *code=responseObject[@"data"][@"code"];
        int returncode = [code intValue];
        NSLog(@"%d",returncode);
        
        if (returncode!=0){
            NSLog(@"%@",@"注册成功！");
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"提示" message:@"注册成功" delegate:nil cancelButtonTitle:@"好的" otherButtonTitles:nil, nil];
            [alert show];
            
            NSString *receivedindex = responseObject[@"data"][@"code"];
            
            NSUserDefaults *userinfo = [NSUserDefaults standardUserDefaults];
            [userinfo setObject:receivedindex forKey:@"savedindex"];
            [userinfo setObject:self.regusername.text forKey:@"savedusername"];

            
            
            //MyProfileViewController *backtoprofile=[[MyProfileViewController alloc]init];
            [self.navigationController popViewControllerAnimated:YES];
            
        }else{
            NSLog(@"%@",@"该用户名已被注册");
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"提示" message:@"该用户名已被注册" delegate:nil cancelButtonTitle:@"好" otherButtonTitles:nil, nil];
            [alert show];
        }
        
        
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        NSLog(@"请求失败--%@",error);
    }];
    
}
@end
