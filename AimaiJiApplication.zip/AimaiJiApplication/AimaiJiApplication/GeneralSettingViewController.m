//
//  GeneralSettingViewController.m
//  AimaiJiApplication
//
//  Created by DMT on 2018/11/29.
//  Copyright © 2018年 Stars. All rights reserved.
//

#import "GeneralSettingViewController.h"

@interface GeneralSettingViewController ()

@end

@implementation GeneralSettingViewController

-(instancetype)init
{
    
    UINavigationItem *navitem=self.navigationItem;
    navitem.title=@"通用";
    
    return self;
}

@end
