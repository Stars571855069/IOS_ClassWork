var mysql = require('mysql');
var express = require('express');
var router = express.Router();


router.use('/', function(req, res, next)
{

    var content=req.body.args.content;
    console.log(content);
    var obj={"data":{}};


    var dbConnection = mysql.createConnection({
        host: 'localhost',
        user: 'root',
        password: '86456343',
        database: 'AimaijiIOSDataBase'
    });

    var sql = ("select * from iteminfo where itemname LIKE '%"+content+"%' ");
    dbConnection.query(sql,function (err,results) {
        if (err) {
            //"retCode":1,
            obj.data.code=0;
        }
        else{

            if (results.length){
                obj.data.code=2;
                obj.data.resultlist=results;
            }
            else{
                obj.data.code=1;
            }
        }
        res.send(obj);
        console.log(obj);
    });

    dbConnection.end();
});
module.exports = router;

