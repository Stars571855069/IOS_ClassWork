var mysql = require('mysql');
var express = require('express');
var router = express.Router();



router.use("/", function(req, res, next) {

    var loggedusername=req.body.args.username;
    const form = new formidable.IncomingForm();

    form.encoding = "utf-8";
    form.uploadDir = "public/Image/UserPhoto/"; //上传文件存储的路径

    form.keepExtensions = true; //保留上传文件的文件后缀

    //form.maxFileSize = 200 * 1024 * 1024;

    form.parse(req, function(err, fields, files) {

        console.log(util.inspect({ fields: fields }));
        var username = fields['username'];
        // var avator = fields['avator'];
        var picture_path = files.img.path;
        // var picture_path=files['picture'].path; //服务器端的存储文件的路径地址
        //需要移除public/前缀后，再存入数据库
        picture_path = picture_path.replace("public", "");
        picture_path = picture_path.replace("images", "images/");
        picture_path = "http://172.20.10.2:3000/" + picture_path;
        //创建数据库连接
        var dbConnection = mysql.createConnection({
            host: '127.0.0.1',
            user: 'root',
            password: '86456343',
            database: 'AimaijiIOSDataBase'
        });

        dbConnection.connect();
        dbConnection.query(
            "UPDATE userinfo SET userphotourl = "+"'"+ picture_path +"'"+'WHERE username = '+"'"+ loggedusername +"'",
            function(err) {
                //插入成功后调用执行这个函数体
                if (err) {
                    console.log(err);
                    res.send({ code: 1, msg: "Upload Failed" });
                } else {
                    res.send({ code: 0, msg: "Upload Success" });
                }
                dbConnection.end();
            }
        );
    });
});
module.exports = router;