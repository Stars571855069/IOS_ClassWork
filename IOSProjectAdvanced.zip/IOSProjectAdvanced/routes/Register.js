var mysql = require('mysql');
var express = require('express');
var router = express.Router();

/* GET home page. */

router.use('/', function(req, res, next)
{

    var adduser_name=req.body.args.regusername;
    var addpassword=req.body.args.regpassword;

    console.log(adduser_name);
    console.log(addpassword);

    var obj={"data":{}};

    var dbConnection = mysql.createConnection({
        host: 'localhost',
        user: 'root',
        password: '86456343',
        database: 'AimaijiIOSDataBase'
    });

        dbConnection.query('INSERT INTO userinfo SET ?', {
                username: adduser_name,
                password: addpassword,
                selfinst:"该用户还没有个人介绍......"
            },
            function (err, result) {

                if (err) {
                    obj.data.code=0;
                    res.send(obj);
                }
                else {
                    obj.data.code=1;
                    obj.data.resultlist=result;
                    res.send(obj);
                }
            } );

    dbConnection.end();
});




module.exports = router;
