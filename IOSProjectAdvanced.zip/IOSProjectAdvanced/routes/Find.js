var mysql = require('mysql');
var express = require('express');
var router = express.Router();

/* GET home page. */


router.use('/', function(req, res, next) {
    var dbConnection = mysql.createConnection({
        host: '127.0.0.1',
        user: 'root',
        password: '86456343',
        database: 'AimaijiIOSDataBase'
    });

    var targetusername=req.body.args.username;
    var obj={"data":{}};
    var apicode = req.body.apicode;
    console.log(apicode);
   // ordered by commentdate

    function fmtDate(obj){
        var date =  new Date(obj);
        var y = 1900+date.getYear();
        var m = "0"+(date.getMonth()+1);
        var d = "0"+date.getDate();
        return y+"-"+m.substring(m.length-2,m.length)+"-"+d.substring(d.length-2,d.length);
    }

    if(apicode==="viewcomment") {
        var sql = ("select * from comment where commentuser ='" + targetusername + "' order by commentdate DESC ");
        dbConnection.query(sql, function (err, results) {
            if (err) {
                //"retCode":1,
                obj.data.code = 0;
            } else {

                if (results.length) {
                    obj.data.code = 2;
                    for(var i=0;i<results.length;i++){
                        fmtDate(results[i].commentdate);
                    }
                    obj.data.commentlist = results;

                } else {
                    obj.data.code = 1;
                }
            }
            res.send(obj);
            console.log(obj);
        });
    }
    else{
        var addtargetusername=req.body.args.commentuser;
        var targetuserphoto=req.body.args.commentuserphoto;
        var targetcomment=req.body.args.comment;
        var targetdate=req.body.args.commentdate;

        var formatteddate=fmtDate(targetdate);
        //console.log(tname);
        //console.log(searchname);
        console.log("adding content to comment");
        console.log(addtargetusername);
        console.log(targetuserphoto);
        console.log(targetcomment);
        console.log(formatteddate);


        dbConnection.query('INSERT INTO comment SET ?', {
                commentuser: addtargetusername,
                commentuserphoto: targetuserphoto,
                comment:targetcomment,
                commentdate:targetdate
            },
            function (err, result) {

                if (err) {
                    obj.data.code=0;

                }
                else {
                    obj.data.code=1;
                }
                res.send(obj);

            } );
    }
    dbConnection.end();
});


// router.post('/', function(req, res, next)
// {
//
//     var infogoto=req.body.typename;
//
//     var dbConnection = mysql.createConnection({
//         host: 'localhost',
//         user: 'root',
//         password: '86456343',
//         database: 'aimaijidatabase'
//     });
//     console.log(infogoto);
//     var sql = ("select * from iteminfo where itemname = '"+infogoto+"' ");
//     dbConnection.query(sql,function (err,results) {
//         if(err)
//         {
//             throw err;
//
//         }
//         else {
//             console.log(results);
//             if (results[0]) {
//
//                 res.render('ItemInfo',{title:"商品详情",ItemInfo:results[0]});
//                 //     res.redirect('/SearchResults');
//
//             }
//             else res.send( '<script>alert("未找到该商品的详情页面");window.location.href="/Find"</script>');
//         }
//     });
//     dbConnection.end(function () {
//         console.log("end connect");
//     });
// });

module.exports = router;