var mysql = require('mysql');
var express = require('express');
var router = express.Router();

/* GET home page. */



/* GET home page. */
router.use('/', function(req, res, next)
{
    var apicode = req.body.apicode;
    console.log(apicode);
    var obj={"data":{}};


    var dbConnection = mysql.createConnection({
        host: 'localhost',
        user: 'root',
        password: '86456343',
        database: 'AimaijiIOSDataBase'
    });
    if(apicode==="view")
    {
        console.log("Preparing iteminfo");
        var tname = req.body.args.content;
        var requestuser = req.body.args.searchname;
        console.log(tname);
        console.log(requestuser);


        var sql = ("select * from iteminfo where itemname = '" + tname + "'");
        dbConnection.query(sql, function (err, results) {
            if (err) {
                //"retCode":1,
                obj.data.code = 0;
            } else {

                if (results && results.length) {
                    console.log(results);
                    obj.data.code = 2;
                    obj.data.itemname = results[0].itemname;
                    obj.data.itemdetail = results[0].itemdetail;
                    obj.data.itemimage = results[0].itemimageurl;
                    obj.data.itemprice = results[0].itemprice;


                } else if (!results.length) {
                    obj.data.code = 1;
                } else {
                    obj.data.code = 0;
                }
            }
            res.send(obj);
            console.log(obj);
        });


    }
    else{
        {

            var targetitemname=req.body.args.collectname;
            var targetuser=req.body.args.targetname;
            var targetprice=req.body.args.targetprice;
            var targetimageurl=req.body.args.targetimage;
            //console.log(tname);
            //console.log(searchname);
            console.log("adding content to usercart");
            console.log(targetitemname);
            console.log(targetimageurl);
            console.log(targetprice);
            console.log(targetuser);


            dbConnection.query('INSERT INTO usercart SET ?', {
                    itemname: targetitemname,
                    itemimageurl: targetimageurl,
                    itemprice:targetprice,
                    itemowner:targetuser
                },
                function (err, result) {

                    if (err) {
                        obj.data.code=0;
                        //res.send('<script>alert("添加失败！该商品已存在于你的购物车中！");window.location.href="/ItemInfo"</script>');
                        //dbConnection.end();
                    }
                    else {
                        obj.data.code=1;
                        //res.send( '<script>alert("添加成功！");window.location.href="/ItemInfo"</script>');
                        //dbConnection.end(); //关闭数据库连接
                    }
                    res.send(obj);

                } );
        }
    }
    dbConnection.end();
});



module.exports = router;