var mysql = require('mysql');
var express = require('express');
var router = express.Router();

/* GET home page. */



/* GET home page. */
router.use('/', function(req, res, next)
{
    var dbConnection = mysql.createConnection({
        host: '127.0.0.1',
        user: 'root',
        password: '86456343',
        database: 'AimaijiIOSDataBase'
    });

    var apicode = req.body.apicode;
    console.log(apicode);
    var obj={"data":{}};

    if(apicode==="typedisplay")
    {
        dbConnection.query('SELECT * FROM typeinfo order by typename DESC',function (err, result) {
            if (err) {
                //"retCode":1,
                obj.data.code=1;


            }
            else{
                obj.data.code=0;
                obj.data.typelist=result;
                console.log(result);
                }
            res.send(obj);
        });
    }
    else
    {
        var targetbrand=req.body.args.targetbrand;

        console.log(targetbrand);
        var sql = ("select * from iteminfo where itembrand = '"+targetbrand+"' ");
        dbConnection.query(sql,function (err,results) {
            if (err) {
                //"retCode":1,
                obj.data.code=0;
            }
            else if(results && results.length){
                obj.data.code=2;
                obj.data.typeitemlist=results;
                console.log(results);
            }
                else{
                  obj.data.code=1;
                }
            res.send(obj);
        });
    }
    dbConnection.end();
});


// router.post('/', function(req, res, next)
// {
//
//     var infogoto=req.body.brandname;
//
//     var dbConnection = mysql.createConnection({
//         host: 'localhost',
//         user: 'root',
//         password: '86456343',
//         database: 'AimaijiIOSDataBase'
//     });
//     console.log(infogoto);
//     var sql = ("select * from iteminfo where itembrand = '"+infogoto+"' ");
//     dbConnection.query(sql,function (err,results) {
//         if(err)
//         {
//             throw err;
//
//         }
//         else {
//             console.log(results);
//             if (results[0]) {
//
//                 res.render('ItemBought',{title:"品牌商品",goods:results});
//                 //     res.redirect('/SearchResults');
//
//             }
//             else res.send( '<script>alert("未找到该品牌的手机");window.location.href="/ShopItemType"</script>');
//         }
//     });
//     dbConnection.end(function () {
//         console.log("end connect");
//     });
// });


module.exports = router;