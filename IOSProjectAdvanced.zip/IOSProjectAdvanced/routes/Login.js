var express = require('express');
var router = express.Router();
var mysql = require('mysql');




router.use('/', function(req, res, next)
{

    var loginusername=req.body.args.username;
    var loginpassword=req.body.args.password;

    console.log(loginusername);
    console.log(loginpassword);

    var dbConnection = mysql.createConnection({
        host: '127.0.0.1',
        user: 'root',
        password: '86456343',
        database: 'AimaijiIOSDataBase'
    });

    var sql = ("select * from userinfo where username ='"+loginusername+"' and password = '"+loginpassword+"'" );
    dbConnection.query(sql,function (err,results) {
        if(err)
        {
            throw err;

        }
        else {
            console.log(results);
            if (results[0]){
                if(results[0].username === loginusername && results[0].password === loginpassword)
                {

                    //res.render('Profile',{  title: '个人信息',userinfo:results[0]});
                    //res.send(results);
                    res.send({
                        //"retCode":1,
                        "data":{
                            "sendindex":"1",
                            "sendusername":results[0].username,
                            "senduserphoto":results[0].userphotourl,
                            "senduserinst":results[0].selfinst
                        }
                    });





                    //console.log(results[0].username);

                }
                else{
                    res.send({"retCode":0});
                }
            }
            else res.send({"retCode":0});
        }
    });
    dbConnection.end(function () {
        console.log("end connect");
    });
});

module.exports = router;
